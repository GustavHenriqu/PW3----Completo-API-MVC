import * as Usuario from "../models/usuarioModel.js";

function idValido(id) {
  return /^[1-9]\d*$/.test(String(id));
}

// POST /usuarios
export async function criar(req, res) {
  try {
    const { nome, email } = req.body ?? {};

    if (typeof nome !== "string" || !nome.trim() ||
        typeof email !== "string" || !email.trim()) {
      return res.status(400).json({
        erro: "Os campos nome e email são obrigatórios."
      });
    }

    const usuario = await Usuario.criar(nome.trim(), email.trim());
    return res.status(201).json(usuario);
  } catch (erro) {
    if (erro.code === "ER_DUP_ENTRY") {
      return res.status(409).json({
        erro: "Já existe um usuário cadastrado com esse email."
      });
    }
    console.error(erro);
    return res.status(500).json({ erro: "Falha ao criar usuário." });
  }
}

// GET /usuarios
export async function listar(req, res) {
  try {
    const usuarios = await Usuario.listarTodos();
    return res.status(200).json(usuarios);
  } catch (erro) {
    console.error(erro);
    return res.status(500).json({ erro: "Falha ao listar usuários." });
  }
}

// GET /usuarios/:id
export async function buscar(req, res) {
  try {
    const { id } = req.params;

    if (!idValido(id)) {
      return res.status(400).json({ erro: "ID inválido." });
    }

    const usuario = await Usuario.buscarPorId(id);
    if (!usuario) {
      return res.status(404).json({ erro: "Usuário não encontrado." });
    }

    return res.status(200).json(usuario);
  } catch (erro) {
    console.error(erro);
    return res.status(500).json({ erro: "Falha ao buscar usuário." });
  }
}

// PUT /usuarios/:id
export async function atualizar(req, res) {
  try {
    const { id } = req.params;
    const { nome, email } = req.body ?? {};

    if (!idValido(id)) {
      return res.status(400).json({ erro: "ID inválido." });
    }

    if ((nome !== undefined && (typeof nome !== "string" || !nome.trim())) ||
        (email !== undefined && (typeof email !== "string" || !email.trim()))) {
      return res.status(400).json({
        erro: "Informe um nome ou email válido para atualização."
      });
    }

    if (nome === undefined && email === undefined) {
      return res.status(400).json({
        erro: "Informe ao menos o campo nome ou email."
      });
    }

    const atualizado = await Usuario.atualizar(
      id,
      nome === undefined ? null : nome.trim(),
      email === undefined ? null : email.trim()
    );

    if (!atualizado) {
      return res.status(404).json({ erro: "Usuário não encontrado." });
    }

    return res.status(200).json({ mensagem: "Usuário atualizado com sucesso." });
  } catch (erro) {
    if (erro.code === "ER_DUP_ENTRY") {
      return res.status(409).json({
        erro: "Já existe um usuário cadastrado com esse email."
      });
    }
    console.error(erro);
    return res.status(500).json({ erro: "Falha ao atualizar usuário." });
  }
}

// DELETE /usuarios/:id
export async function excluir(req, res) {
  try {
    const { id } = req.params;

    if (!idValido(id)) {
      return res.status(400).json({ erro: "ID inválido." });
    }

    const excluido = await Usuario.excluir(id);
    if (!excluido) {
      return res.status(404).json({ erro: "Usuário não encontrado." });
    }

    return res.status(200).json({ mensagem: "Usuário excluído com sucesso." });
  } catch (erro) {
    console.error(erro);
    return res.status(500).json({ erro: "Falha ao excluir usuário." });
  }
}
