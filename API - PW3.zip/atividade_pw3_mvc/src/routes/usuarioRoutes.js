import { Router } from "express";
import * as usuarioController from "../controllers/usuarioController.js";

const router = Router();

router.post("/", usuarioController.criar);
router.get("/", usuarioController.listar);
router.get("/:id", usuarioController.buscar);
router.put("/:id", usuarioController.atualizar);
router.delete("/:id", usuarioController.excluir);

export default router;
