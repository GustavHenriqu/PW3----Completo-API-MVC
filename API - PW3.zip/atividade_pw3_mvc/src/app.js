import express from "express";
import cors from "cors";
import usuarioRoutes from "./routes/usuarioRoutes.js";

const app = express();

app.use(cors());
app.use(express.json());

// Rotas da API
app.use("/usuarios", usuarioRoutes);

// Tratamento de rota inexistente
app.use((req, res) => {
  res.status(404).json({ erro: "Rota não encontrada." });
});

export default app;
