import { pool } from "../config/db.js";

// CREATE: cadastra um usuário
export async function criar(nome, email) {
  const [result] = await pool.query(
    "INSERT INTO usuarios (nome, email) VALUES (?, ?)",
    [nome, email]
  );
  return { id: result.insertId, nome, email };
}

// READ: lista todos os usuários
export async function listarTodos() {
  const [rows] = await pool.query(
    "SELECT id, nome, email FROM usuarios ORDER BY id"
  );
  return rows;
}

// READ: busca um usuário pelo ID
export async function buscarPorId(id) {
  const [rows] = await pool.query(
    "SELECT id, nome, email FROM usuarios WHERE id = ?",
    [id]
  );
  return rows[0] || null;
}

// UPDATE: atualiza nome e/ou email
export async function atualizar(id, nome, email) {
  const [result] = await pool.query(
    "UPDATE usuarios SET nome = COALESCE(?, nome), email = COALESCE(?, email) WHERE id = ?",
    [nome ?? null, email ?? null, id]
  );
  return result.affectedRows > 0;
}

// DELETE: remove um usuário
export async function excluir(id) {
  const [result] = await pool.query(
    "DELETE FROM usuarios WHERE id = ?",
    [id]
  );
  return result.affectedRows > 0;
}
